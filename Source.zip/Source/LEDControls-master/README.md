# LEDControls
A free Lazarus LED components suite

The package contains 4 LED style components:

TBlinker
TSegmentDisplay
TLedMeter
TSignalStrength

The package LEDControls depends on package BGRABitmapPack (only component TSegmentDisplay).

Documentation: www.atomek.de/coding/ledcontrols

Installation

Pull all files to a local folder like ATOMEK.Controls,
install the package BGRABitmapPack
and compile the package ledcontrols.lpk and install it.

I developed it with Windows 10 64-bit. Please try it under Linux or macOS and let me know
if it works (it should). jan@atomek.de, www.atomek.de
